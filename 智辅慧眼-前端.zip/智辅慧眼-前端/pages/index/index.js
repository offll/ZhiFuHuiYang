// 引入微信同声传译插件，用于 ASR(语音转文字) 和 TTS(文字转语音)
const plugin = requirePlugin("WechatSI");
const manager = plugin.getRecordRecognitionManager();
// 引入腾讯地图 LBS SDK，用于步行路线规划
const QQMapWX = require('../../libs/qqmap-wx-jssdk.min.js');
let qqmapsdk;

Page({
  data: {
    isLive: false,        // 是否开启了摄像头实时巡视守护
    isNavigating: false,  // 是否正处于地图导航状态
    isAnalyzing: false,   // 核心防崩溃锁：标记后端是否正在处理上一帧图片
    voiceText: "系统初始化完成，长按提问，双击开启监测", // 屏幕显示的提示文字
    lastBroadcast: "",    // 记录上一次播报的内容，用于防止重复啰嗦播报同一句话
    showNavInput: false   // 是否显示手动输入目的地的弹窗
  },

  // 页面加载时的初始化工作
  onLoad() {
    this.initVoiceEngine(); // 初始化语音引擎的监听器
    // 初始化腾讯地图 SDK（填入你的专属开发者 Key）
    qqmapsdk = new QQMapWX({ key: 'CRIBZ-5B3WQ-3HA5Z-BIGPR-RNPI6-E4FRW' });
    
    // 初始化摄像头上下文与底层抽帧引擎
    this.ctx = wx.createCameraContext();
    this.initFrameExtractor();
  },

  // ================= 1. 纯静默视频流抽帧引擎 (真·工业级节流) =================
  initFrameExtractor() {
    // 创建底层离屏渲染画板（不在屏幕上显示，专用于图像像素压缩）
    this.canvas = wx.createOffscreenCanvas({ type: '2d' });
    this.canvasCtx = this.canvas.getContext('2d');
    this.lastFrameTime = 0; // 记录上一次成功抽帧的时间戳
    this.pendingQuery = ""; // 用于存储盲人主动提出的问题（如："前面有什么"）

    // 监听相机的每一帧画面（每秒可能触发几十次）
    this.listener = this.ctx.onCameraFrame((frame) => {
      // 节流阀一：如果没有开启守护，或者上一帧发给后端还没返回结果（防阻塞锁），直接丢弃该帧
      if (!this.data.isLive || this.data.isAnalyzing) return;

      const now = Date.now();
      // 动态节流阀：导航并发模式下 3000ms 传一帧，常规守护 4000ms 传一帧，节省算力与发热
      const interval = this.data.isNavigating ? 3000 : 4000;

      // 核心丢帧策略：如果距离上次传图还没到规定时间间隔，且盲人没有主动提问，直接丢弃
      if (now - this.lastFrameTime < interval && this.pendingQuery === "") {
        return;
      }
      
      // 更新抽帧时间，并把这一帧推入处理流水线
      this.lastFrameTime = now;
      this.processVideoFrame(frame, this.pendingQuery);
      this.pendingQuery = ""; // 消费完毕，清空盲人的提问缓存
    });
  },

  // 处理并压缩图像帧
  processVideoFrame(frame, query) {
    this.setData({ isAnalyzing: true }); // 加锁：告诉系统我正在处理，别再送新帧进来了

    try {
      // 动态对齐离屏画板的宽高，彻底杜绝 Canvas 内存溢出越界崩溃
      if (this.canvas.width !== frame.width || this.canvas.height !== frame.height) {
        this.canvas.width = frame.width;
        this.canvas.height = frame.height;
      }

      // 高效转换相机的 RGBA 像素阵列为标准图像数据
      const data = new Uint8ClampedArray(frame.data);
      const imageData = this.canvas.createImageData(data, frame.width, frame.height);
      this.canvasCtx.putImageData(imageData, 0, 0);

      // 核心压缩算法：转为 JPEG 格式，画质压到 40% (0.4的画质足够 YOLO 识别，且能把体积降到极低，传输极快)
      const base64Data = this.canvas.toDataURL('image/jpeg', 0.4).split(',')[1];
      
      // 发送给 Spring Boot 后端
      this.sendToBackend(base64Data, query);

    } catch (err) {
      console.error("抽帧渲染异常，已安全丢弃:", err);
      this.setData({ isAnalyzing: false }); // 确保发生异常时锁能释放，系统不至于彻底卡死
    }
  },

  // ================= 2. 全局服务管控 =================
  // 一键全局熔断：彻底关闭所有后台吃性能的服务（导航、摄像头、语音）
  stopAllServices() {
    if (this.navTimer) clearTimeout(this.navTimer);
    if (this.touchTimer) clearTimeout(this.touchTimer);
    if (this.listener) this.listener.stop(); // 停止截获视频流
    
    // 重置所有状态机
    this.setData({ 
      isLive: false, 
      isNavigating: false, 
      showNavInput: false,
      isAnalyzing: false, 
      voiceText: "监测与导航已安全关闭",
      lastBroadcast: "" 
    });
    
    wx.vibrateShort({ type: 'medium' }); // 短震动物理反馈
    this.speakFeedback("已为您关闭所有辅助系统");
  },

  // 开启视觉巡视守护
  startLiveMonitor() {
    this.setData({ isLive: true });
    this.lastFrameTime = 0; // 重置时间，让监听器立刻抓取下一张第一帧
    if (this.listener) this.listener.start(); // 开启视频流截获监听
    this.speakFeedback("实时视觉守护已开启，为您保驾护航");
  },

  // ================= 3. 与后端通信 =================
  sendToBackend(base64Data, query) {
    wx.request({
      // 向局域网内的 Spring Boot 后台发起 POST 请求
      url: 'http://172.20.10.11:8080/api/vision/stream', 
      method: 'POST',
      data: { 
        image: base64Data, 
        query: query,
        isNavMode: this.data.isNavigating // 告诉后端我现在开没开导航，方便它决定要不要拦截避障提示
      },
      success: (res) => {
        let reply = res.data;
        if (!reply) return;

        // 场景 A：盲人主动提问，无论通畅还是危险，必须给出回答
        if (query !== "") {
          this.setData({ voiceText: reply, lastBroadcast: reply });
          this.speakFeedback(reply);
          return;
        }

        // 场景 B：自动巡视状态下，前面没危险（道路通畅）
        if (reply === "道路通畅") {
          // 如果上一次报的是危险，现在变通畅了，就告诉盲人“危险解除”。如果一直通畅，就保持闭嘴，不啰嗦。
          if (this.data.lastBroadcast !== "道路通畅" && this.data.lastBroadcast !== "") {
            this.setData({ voiceText: reply, lastBroadcast: "道路通畅" });
            this.speakFeedback("前方道路已通畅"); 
          }
          return; 
        }

        // 场景 C：自动巡视发现【新危险】（跟上次播报的不一样）
        if (reply !== this.data.lastBroadcast) {
          this.setData({ voiceText: reply, lastBroadcast: reply });
          // 如果后端传来的字符串里带有【停】字标识，说明是极危近距障碍
          if (reply.includes("【停】")) {
            wx.vibrateLong(); // 强制触发手机长震动，实现听觉、触觉双重保命预警
          }
          this.speakFeedback(reply);
        }
      },
      fail: (err) => {
        console.error("网络异常", err);
      },
      complete: () => { 
        this.setData({ isAnalyzing: false }); // 核心：无论请求成功还是失败，都把防崩溃锁彻底释放，允许截取下一帧图像
      }
    });
  },

  // ================= 4. 语音与交互引擎 =================
  // TTS（文字转语音）合成与播放方法
  speakFeedback(text) {
    plugin.textToSpeech({
      lang: "zh_CN", tts: true, content: text,
      success: (res) => {
        // 播放新语音前，先销毁旧的播放实例，防止声音重叠打架
        if(this.audioCtx) this.audioCtx.destroy(); 
        this.audioCtx = wx.createInnerAudioContext();
        this.audioCtx.src = res.filename; // 拿到同声传译生成的 mp3 文件地址
        this.audioCtx.autoplay = true;    // 自动播放
      }
    });
  },

  // 盲操：手指长按屏幕任意位置触发录音
  handleTouchStart(e) {
    this.startTime = e.timeStamp;
    // 延迟 500ms 确认是长按，防止正常的屏幕滑动被误判
    this.touchTimer = setTimeout(() => {
      wx.vibrateShort({ type: 'heavy' }); // 给一个重震动，告诉盲人开始录音了
      manager.start({ lang: "zh_CN" });   // 唤起录音引擎
    }, 500); 
  },

  // 盲操：手指松开/双击逻辑
  handleTouchEnd(e) {
    if (this.touchTimer) clearTimeout(this.touchTimer); // 清除长按判定定时器
    const duration = e.timeStamp - this.startTime;
    manager.stop(); // 手指离开，停止录音

    // 判定【双击急停】逻辑：如果按下的时间极短（不到300ms），说明是一次轻点
    if (duration < 300) { 
      const now = e.timeStamp;
      // 两次轻点时间间隔小于400ms，判定为完美双击
      if (this.lastTapTime && (now - this.lastTapTime < 400)) { 
        // 双击切换状态：如果开着就关掉，如果关着就开启
        if (this.data.isLive || this.data.isNavigating) {
           this.stopAllServices(); 
        } else {
           this.startLiveMonitor();
        }
        this.lastTapTime = 0; 
      } else {
        this.lastTapTime = now; // 记录第一次点击时间
      }
    }
  },

  // 语音指令正则表达式解析引擎
  initVoiceEngine() {
    manager.onStop = (res) => {
      if (res.result) {
        // 清除语音识别出来的标点符号
        let text = res.result.replace(/[。，！!.,]/g, '');
        this.setData({ voiceText: "听到指令：" + text });

        // 意图抽取 1：路线导航类
        if (text.includes("带我去") || text.includes("导航到") || text.includes("我要去")) {
          // 正则剥离动词，提取出目的地名词实体（如把"带我去食堂"变成"食堂"）
          let dest = text.replace(/(带我去|导航到|我要去|请帮我)/g, "");
          this.startNavigationLogic(dest); // 发起 LBS 导航请求
          return;
        }
        // 意图抽取 2：系统控制类 (关)
        if (text.includes("关闭") || text.includes("停止") || text.includes("退出")) {
          this.stopAllServices();
          return;
        }
        // 意图抽取 3：系统控制类 (开)
        if (text.includes("开启守护") || text.includes("打开监测")) {
          this.startLiveMonitor();
          return;
        }
        
        // 意图抽取 4：环境发问类（【抽帧版主动拦截术】）
        // 把盲人问的话挂载到缓存变量上，同时把 lastFrameTime 归零，强制绕过定时器，立刻截取下一帧传给后端！
        this.pendingQuery = text;
        this.lastFrameTime = 0; 
        
        // 如果盲人问的时候，根本没开启实时守护怎么办？临时拍一张单张照片传过去！
        if (!this.data.isLive) {
           this.captureSingleFrameForQuery();
        }
      }
    };
  },

  // 兜底方案：在没开启连续视频流的情况下，临时拍一张静态照片传给后端测距
  captureSingleFrameForQuery() {
    this.ctx.takePhoto({
      quality: 'low',
      success: (res) => {
        const fs = wx.getFileSystemManager();
        const base64 = fs.readFileSync(res.tempImagePath, 'base64');
        this.sendToBackend(base64, this.pendingQuery);
        this.pendingQuery = ""; // 消费掉问题
      }
    });
  },

  // ================= 5. 导航模块 =================
  // 启动 LBS 导航路线规划
  startNavigationLogic(destinationName) {
    const that = this;
    if (this.navTimer) clearTimeout(this.navTimer);
    // 【系统算力保护】：开始向云端请求地图数据时，强制暂停本地摄像头的疯狂抽帧，节约手机性能
    if (this.listener) this.listener.stop(); 

    this.setData({
      showNavInput: false,
      isNavigating: true,
      isLive: false,
      voiceText: "正在为您规划路线..."
    });
    this.speakFeedback(`正在规划前往${destinationName}的路线，请稍候`);

    // 1. 获取用户当前的经纬度 GPS 坐标
    wx.getLocation({
      type: 'gcj02',
      success: (res) => {
        // 2. 调用腾讯地图 POI 检索接口，把"图书馆"这类文字地点转换为终点经纬度
        qqmapsdk.search({
          keyword: destinationName,
          location: `${res.latitude},${res.longitude}`,
          success: (searchRes) => {
            // 如果成功找到了这个地点
            if (searchRes.data && searchRes.data.length > 0) {
              const target = searchRes.data[0].location;
              // 3. 将起点和终点的经纬度传给算路引擎
              that.calculateWalkingRoute(res.latitude, res.longitude, target.lat, target.lng, destinationName);
            } else {
              // 防御性设计：如果地名太偏或者瞎说的，直接退出，防止程序死锁
              that.speakFeedback("抱歉，未找到该地点，已退出导航");
              that.stopAllServices();
            }
          }
        });
      }
    });
  },

  // 计算 LBS 步行具体路线并融合视觉守护
  calculateWalkingRoute(fromLat, fromLng, toLat, toLng, destName) {
    const that = this;
    qqmapsdk.direction({
      mode: 'walking', // 指定为步行模式，这样不会把盲人导上高速公路
      from: { latitude: fromLat, longitude: fromLng },
      to: { latitude: toLat, longitude: toLng },
      success: (res) => {
        // 如果成功获取了路线规划
        if (res.status === 0 && res.result.routes.length > 0) {
          const route = res.result.routes[0];
          const firstStep = route.steps[0].instruction; // 提取路线的第一步指引（例如"向北走50米"）
          
          this.setData({ voiceText: `目标: ${destName}\n距离: ${route.distance}米\n指引: ${firstStep}` });
          this.speakFeedback(`规划成功，全程${route.distance}米。当前指引：${firstStep}`);

          // 【多模态无缝衔接核心】：规划成功并开始播报语音后，利用定时器强行挂起 6 秒。
          // 确保地图的长语音播完之后，自动唤醒摄像头，无缝切入"带防冲突的视觉守护状态"！
          this.navTimer = setTimeout(() => {
            if (that.data.isNavigating) that.startLiveMonitor(); 
          }, 6000);
        }
      }
    });
  },

  // 辅助表单的事件处理逻辑
  confirmNav() {
    if (!this.destValue) return wx.showToast({ title: '请输入', icon: 'none' });
    this.startNavigationLogic(this.destValue);
  },
  startNavigation() { this.setData({ showNavInput: true }); },
  cancelNav() { this.setData({ showNavInput: false }); },
  onDestInput(e) { this.destValue = e.detail.value; }
});