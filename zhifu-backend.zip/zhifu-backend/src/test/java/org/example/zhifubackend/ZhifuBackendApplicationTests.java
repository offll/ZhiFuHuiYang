package org.example.zhifubackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZhifuBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
