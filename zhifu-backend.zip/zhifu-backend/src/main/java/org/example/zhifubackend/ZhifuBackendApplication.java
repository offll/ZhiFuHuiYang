package org.example.zhifubackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

// @SpringBootApplication 这是一个组合注解，代表这是整个项目的启动入口
// 它会自动扫描当前包（org.example.zhifubackend）下所有的类，把带注解的类加载进容器
@SpringBootApplication
public class ZhifuBackendApplication {

    // Java 程序的常规 main 函数主入口
    public static void main(String[] args) {
        // 一键启动内嵌的 Tomcat 服务器和 Spring 容器
        SpringApplication.run(ZhifuBackendApplication.class, args);
    }


    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}