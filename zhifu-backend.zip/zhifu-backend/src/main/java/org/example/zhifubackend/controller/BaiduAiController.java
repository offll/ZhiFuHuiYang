//package org.example.zhifubackend.controller;
//
//import com.fasterxml.jackson.databind.JsonNode;
//import org.example.zhifubackend.service.BaiduAiService;
//import org.example.zhifubackend.service.SpatialEngine;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//import java.io.FileOutputStream;
//import java.io.OutputStream;
//import java.util.Base64;
//import java.util.Map;
//import java.io.File;
//
//@RestController
//@RequestMapping("/api/vision")
//@CrossOrigin
//public class BaiduAiController {
//
//    @Autowired
//    private BaiduAiService baiduAiService;
//
//    @Autowired
//    private SpatialEngine spatialEngine;
//
//    private static final String DATASET_PATH = "E:/Java_Space/blind_data/";
//
//    @PostMapping("/stream")
//    public String handleVideoStream(@RequestBody Map<String, Object> payload) {
//
//        String base64Image = (String) payload.get("image");
//        String query = (String) payload.get("query");
//
//        // 获取小程序传过来的导航状态，如果没有传，默认为 false
//        boolean isNavMode = false;
//        if (payload.containsKey("isNavMode")) {
//            isNavMode = (boolean) payload.get("isNavMode");
//        }
//
//        if (base64Image == null || base64Image.isEmpty()) return "未检测到画面";
//
//        // 1. 保存这一帧作为训练素材
//        saveImage(base64Image);
//
//        // 2. 调用识别
//        JsonNode result = baiduAiService.identifyImageBase64(base64Image);
//
//        // 3. 空间决策（传入三个参数：结果、查询词、导航状态）
//        if (result == null) return "引擎扫描中...";
//
//        return spatialEngine.analyze(result, query, isNavMode);
//    }
//
//    //将 Base64 图片保存到本地文件夹
//    private void saveImage(String base64Data) {
//        try {
//            File folder = new File(DATASET_PATH);
//            if (!folder.exists()) folder.mkdirs();
//
//            String fileName = System.currentTimeMillis() + ".jpg";
//            byte[] imageBytes = Base64.getDecoder().decode(base64Data);
//
//            try (OutputStream os = new FileOutputStream(DATASET_PATH + fileName)) {
//                os.write(imageBytes);
//            }
//            System.out.println("已保存素材: " + fileName);
//        } catch (Exception e) {
//            System.err.println("存图失败: " + e.getMessage());
//        }
//    }
//}