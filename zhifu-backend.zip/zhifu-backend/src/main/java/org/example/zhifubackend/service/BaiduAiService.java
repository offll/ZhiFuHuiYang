//package org.example.zhifubackend.service;
//
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.*;
//import org.springframework.stereotype.Service;
//import org.springframework.util.LinkedMultiValueMap;
//import org.springframework.util.MultiValueMap;
//import org.springframework.web.client.RestTemplate;
//import java.util.Map;
//
//@Service
//public class BaiduAiService {
//
//    @Autowired
//    private RestTemplate restTemplate;
//
//    @Autowired
//    private ObjectMapper objectMapper;
//
//    // APIKey
//    private final String API_KEY = "RDbQtgkvl1qcxKVnVpAirKQC";
//    private final String SECRET_KEY = "KMdZlk5vMxR3A1ssRPQJBlmuA666zoKv";
//
//    private String cachedToken = null;
//    private long expireTime = 0;
//
//    public String getAccessToken() {
//        if (cachedToken != null && System.currentTimeMillis() < expireTime) {
//            return cachedToken;
//        }
//        String url = "https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id="
//                + API_KEY + "&client_secret=" + SECRET_KEY;
//        try {
//            Map response = restTemplate.getForObject(url, Map.class);
//            if (response != null && response.containsKey("access_token")) {
//                cachedToken = (String) response.get("access_token");
//                Number expiresIn = (Number) response.get("expires_in");
//                expireTime = System.currentTimeMillis() + (expiresIn.longValue() - 3600) * 1000L;
//                return cachedToken;
//            }
//        } catch (Exception e) {
//            System.err.println("获取百度Token失败，请检查网络或Key是否正确");
//        }
//        return null;
//    }
//
//    public JsonNode identifyImageBase64(String base64Image) {
//        try {
//            String accessToken = getAccessToken();
//            if (accessToken == null) return null;
//
//            //“多主体检测”接口
//            String url = "https://aip.baidubce.com/rest/2.0/image-classify/v1/multi_object_detect?access_token=" + accessToken;
//
//            HttpHeaders headers = new HttpHeaders();
//            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
//
//            MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
//            map.add("image", base64Image);
//
//            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);
//            String resultJson = restTemplate.postForObject(url, request, String.class);
//
//            JsonNode root = objectMapper.readTree(resultJson);
//
//            if (root.has("error_code")) {
//                System.err.println("百度AI识别错误: " + root.get("error_msg").asText());
//                return null;
//            }
//            return root;
//        } catch (Exception e) {
//            return null;
//        }
//    }
//}