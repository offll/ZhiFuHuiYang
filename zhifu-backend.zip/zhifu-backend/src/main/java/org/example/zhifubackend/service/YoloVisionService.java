package org.example.zhifubackend.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.HashMap;
import java.util.Map;

// @Service 声明这是一个业务逻辑层的服务组件
@Service
public class YoloVisionService {

    // 注入启动类里配置好的 RestTemplate，用于发送 HTTP 请求
    @Autowired
    private RestTemplate restTemplate;

    // 注入 Jackson 的 ObjectMapper，用于把 JSON 字符串转化为可以操作的节点树 (JsonNode)
    @Autowired
    private ObjectMapper objectMapper;

    // 常量：指向本地显卡（GPU）运行的 Python Flask 微服务 API 地址
    // 注意：127.0.0.1 表示本机，5000 是 Flask 默认端口
    private final String YOLO_API_URL = "http://127.0.0.1:5000/detect";

    /**
     * 将图片发送给 Python 端进行 YOLO 识别
     * @param base64Image 前端传来的 Base64 格式图像码
     * @return Python 返回的检测结果（JSON 节点格式）
     */
    public JsonNode identifyWithLocalModel(String base64Image) {
        try {
            // 创建 HTTP 请求头
            HttpHeaders headers = new HttpHeaders();
            // 告诉 Python 端，我们要传的数据格式是 JSON
            headers.setContentType(MediaType.APPLICATION_JSON);

            // 创建 HTTP 请求体：封装我们要发给 Python 的数据
            Map<String, String> requestBody = new HashMap<>();
            requestBody.put("image", base64Image);

            // 将请求头和请求体合并成一个完整的 HttpEntity 对象
            HttpEntity<Map<String, String>> request = new HttpEntity<>(requestBody, headers);

            // 发起内网 HTTP POST 请求，由于是内网走本地环回（Loopback），传输耗时极低
            // restTemplate 会阻塞等待 Python 端返回结果（通常几十毫秒）
            String resultJson = restTemplate.postForObject(YOLO_API_URL, request, String.class);

            // 如果 Python 成功返回了包含检测结果的 JSON 字符串
            if (resultJson != null && !resultJson.isEmpty()) {
                // 利用 objectMapper 将纯文本解析成结构化的 JsonNode 对象，方便 SpatialEngine 提取数据
                return objectMapper.readTree(resultJson);
            }
            return null; // 如果返回空，说明没识别到或异常
        } catch (Exception e) {
            // 捕获异常：通常是因为忘记开 Python 黑窗口，或者端口被占用导致拒绝连接
            System.err.println("[危险异常] YOLO微服务连接失败，请检查Python端(5000端口)是否已启动！报错信息: " + e.getMessage());
            return null; // 返回 null 降级处理，保证主后端不崩溃
        }
    }
}