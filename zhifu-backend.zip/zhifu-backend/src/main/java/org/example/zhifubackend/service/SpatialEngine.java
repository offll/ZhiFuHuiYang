package org.example.zhifubackend.service;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Component;
import java.util.*;

// @Component 注解表示这是一个由 Spring 容器管理的通用组件（Bean），可以在其他地方被自动注入
@Component
public class SpatialEngine {
    // === 核心单目测距物理标定参数 ===
    // 盲人将手机佩戴在胸前时，摄像头距离地面的大致物理高度 (单位：米)
    private static final double CAMERA_H = 1.35;
    // 摄像头的等效焦距标定值 (单位：像素)，需根据具体测试手机型号微调
    private static final double FOCAL_PX = 920.0;
    // 画面中“天地交界线”（地平线）的 Y 轴基础坐标值
    private static final int HORIZON_Y = 320;
    // 摄像头截取画面的总宽度 (单位：像素)，用于计算物体在左边还是右边
    private static final int IMAGE_WIDTH = 640;

    /**
     * 核心分析方法：解析 YOLO 结果并生成最终的避障或导航语音文本
     * @param root YOLO 微服务返回的完整 JSON 数据
     * @param query 用户输入的语音询问文本（如果有）
     * @param isNavMode 当前是否处于 LBS 地图导航模式
     * @return 需要通过 TTS 播报给盲人的最终字符串
     */
    public String analyze(JsonNode root, String query, boolean isNavMode) {
        // 判断用户是否发起了主动语音询问（如果 query 不为空，说明盲人主动问了“前面有什么”）
        boolean isQuery = (query != null && !query.isEmpty());

        // 如果 Python 端没有返回数据，或者返回的 JSON 里没有 "result" 字段（没认出任何东西）
        if (root == null || !root.has("result")) {
            // 如果是主动问的，就啰嗦一点回答；如果是后台静默守护，就简短回答
            return isQuery ? "前方道路通畅，未发现明显障碍物" : "道路通畅";
        }

        // 提取 JSON 中的 "result" 数组（里面包含了画面里所有检测到的物体）
        JsonNode resultNode = root.path("result");
        // 创建一个列表，用来存放解析转换后的目标对象
        List<DetectedObject> objects = new ArrayList<>();

        // 遍历所有检测到的物体
        resultNode.forEach(node -> {
            // 将 JSON 节点封装成自定义的 DetectedObject 类，同时在构造函数里计算好距离和方位
            DetectedObject obj = new DetectedObject(node);
            // 语义去噪：过滤掉没有物理边缘的纯墙面背景（wall_surface），防止系统天天报“发现墙壁”干扰盲人
            if (!"wall_surface".equals(obj.rawLabel)) {
                objects.add(obj); // 只有真正的障碍物才加到列表里
            }
        });

        // 经过过滤后，如果画面里没有任何真正有威胁的目标
        if (objects.isEmpty()) {
            return isQuery ? "前方道路通畅，未发现明显障碍物" : "道路通畅";
        }

        // 将所有障碍物按照距离用户的【距离从小到大（由近到远）】进行排序
        objects.sort((a, b) -> Double.compare(a.distance, b.distance));

        // ================= 场景 A：用户主动语音提问 =================
        if (isQuery) {
            // 准备拼接一段完整的语音汇报
            StringBuilder sb = new StringBuilder("您前方有：");
            // 为了防止说话太长盲人记不住，最多只汇报离得最近的 2 个物体
            for (int i = 0; i < Math.min(objects.size(), 2); i++) {
                DetectedObject obj = objects.get(i);
                // 拼接方位、距离（保留1位小数）和中文名称，例如：“正前方1.5米处行人；”
                sb.append(obj.direction).append(String.format("%.1f米处%s；", obj.distance, obj.cnName));
            }
            return sb.toString(); // 返回这段话交给前端 TTS 朗读
        }

        // ================= 场景 B：后台自动守护巡视（盲人没说话，静默走路时） =================
        // 因为已经排过序了，直接取出离用户最近的（最危险的）那个障碍物
        DetectedObject primary = objects.get(0);

        // 【致命危险防线】：下台阶、下楼梯（防踩空），或低矮障碍物（防绊倒）
        if (primary.rawLabel.contains("down") || "obstacle_low".equals(primary.rawLabel)) {
            // 这类致命危险一旦出现在 2 米之内，具有绝对最高优先级
            if (primary.distance < 2.0) {
                // 不管开没开导航，强制带有【停】字提示，前端抓到【停】字会触发强震动！
                return String.format("【停】注意，%s%.1f米发现%s", primary.direction, primary.distance, primary.cnName);
            }
        }

        // 【常规危险防线】：比如行人和上行的台阶
        // 如果它们正好挡在“正前方”，且距离小于 1.5 米
        if ("正前方".equals(primary.direction) && primary.distance < 1.5) {
            return String.format("【停】前方发现%s，距离%.1f米", primary.cnName, primary.distance);
        }

        // 【环境提示 / 防冲突调度】：如果没有开导航，且正前方 3 米内有门或者上台阶
        // (如果是导航模式 isNavMode == true，这步会被跳过，目的就是为了不跟导航语音抢喇叭，即为导航让路)
        if (!isNavMode && "正前方".equals(primary.direction) && primary.distance < 3.0) {
            if (primary.rawLabel.equals("door_frame") || primary.rawLabel.contains("up")) {
                return String.format("前方%.1f米是%s", primary.distance, primary.cnName);
            }
        }

        // 如果远处的物体都没到上面定义的危险距离，就当作通畅处理，保持系统安静
        return "道路通畅";
    }

    // 内部类：用来封装检测到的物体，包含其空间位置的数学计算逻辑
    private class DetectedObject {
        String rawLabel;   // YOLO 原生返回的英文字符串标签 (如: people)
        String cnName;     // 翻译后的中文名称，供语音播报使用
        double distance;   // 算出来的实际物理距离 (米)
        String direction;  // 算出来的相对方位 (左侧/右侧/正前方)

        DetectedObject(JsonNode node) {
            // 获取原生标签
            this.rawLabel = node.path("name").asText();
            // 翻译成中文
            this.cnName = translateLabel(rawLabel);

            // 获取该物体边界框 (Bounding Box) 的坐标信息
            JsonNode loc = node.path("location");
            // 计算边界框最底部的 Y 轴坐标 (顶端Y坐标 + 高度)
            int yBottom = loc.path("top").asInt() + loc.path("height").asInt();

            // ==== 精确单目几何测距核心公式 ====
            // 算出目标底边距离地平线偏移了多少像素。用 Math.max 确保偏移量至少为10，防止分母为零或出现负数导致程序崩溃
            int offset = Math.max(10, yBottom - HORIZON_Y);
            // 物理距离 = (相机高度 * 焦距) / 像素偏移量
            this.distance = (CAMERA_H * FOCAL_PX) / offset;

            // ==== 容错与边界约束 ====
            // 如果底边 Y 坐标大于 620（几乎贴脸了），强制设定距离为 0.5 米极危距离
            if (yBottom > 620) this.distance = 0.5;
            // 因为单目测距在远处误差非常大，如果算出距离大于 8 米，统一封顶收敛为 8 米
            if (this.distance > 8.0) this.distance = 8.0;

            // ==== 精确方位计算 ====
            // 计算识别框中心点的 X 轴坐标
            int centerX = loc.path("left").asInt() + loc.path("width").asInt() / 2;
            // 采用三段式阈值划分：根据中心点在画面中的百分比判定方位
            if (centerX < IMAGE_WIDTH * 0.35) direction = "左侧";
            else if (centerX > IMAGE_WIDTH * 0.65) direction = "右侧";
            else direction = "正前方"; // 在中间 35% ~ 65% 的区域
        }

        // 字典翻译映射：把模型训练时的英文标签翻译成盲人能听懂的自然口语
        private String translateLabel(String label) {
            switch (label) {
                case "steps_up": return "向上的台阶";
                case "steps_down": return "向下的台阶边缘";
                case "stairs_up": return "上行楼梯";
                case "stairs_down": return "下行楼梯";
                case "people": return "行人";
                case "obstacle_low": return "低矮路障";
                case "door_frame": return "门框";
                case "wall_base": return "墙根";
                default: return "障碍物"; // 兜底处理
            }
        }
    }
}