package org.example.zhifubackend.service;

import com.fasterxml.jackson.databind.JsonNode;
import org.example.zhifubackend.service.YoloVisionService;
import org.example.zhifubackend.service.SpatialEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

// @RestController 声明这是一个 RESTful 风格的控制器，返回的数据会自动转化为 JSON/String
@RestController
// @RequestMapping 定义了该类下所有接口的父路径
@RequestMapping("/api/vision")
// @CrossOrigin 允许跨域请求，方便微信小程序前端等不同源设备的直接调用
@CrossOrigin
public class VisionController {

    // 依赖注入：把与 Python 打交道的服务层组件拿过来用
    @Autowired
    private YoloVisionService yoloVisionService;

    // 依赖注入：把空间算法大脑组件拿过来用
    @Autowired
    private SpatialEngine spatialEngine;

    /**
     * 处理前端不断传来的视频流抽帧请求
     * 对应前端的请求地址: POST http://你的域名/api/vision/stream
     * @param payload 前端传来的 JSON 请求体（包含 Base64 图片、语音词、导航状态）
     * @return 最终播报给盲人的提示字符串
     */
    @PostMapping("/stream")
    public String handleVideoStream(@RequestBody Map<String, Object> payload) {
        // 从请求体中提取 Base64 格式的图像数据
        String base64Image = (String) payload.get("image");
        // 提取盲人发起的语音查询内容（可能为空）
        String query = (String) payload.get("query");

        // 安全获取导航状态：检查前端有没有传 "isNavMode" 这个字段，没有就默认当作 false(没在导航)
        boolean isNavMode = payload.containsKey("isNavMode") && (boolean) payload.get("isNavMode");

        // 异常处理：如果前端没把图片传过来，直接打回
        if (base64Image == null || base64Image.isEmpty()) {
            return "未检测到画面";
        }

        // 第一步：调用 YoloVisionService，把图片通过 HTTP 发给局域网内的 Python YOLO 微服务进行推理
        JsonNode result = yoloVisionService.identifyWithLocalModel(base64Image);

        // 如果 YOLO 推理出错、或者 Python 服务器没开导致没拿到结果，采取静默容错策略
        if (result == null) {
            return "安全"; // 返回"安全"防止前端无脑乱报引发恐慌
        }

        // 第二步：将 Python 返回的 Bounding Box 结果交由 SpatialEngine 做几何解算和防冲突过滤
        // 返回算好的最终字符串，SpringBoot 会把这串字直接返回给微信小程序响应体
        return spatialEngine.analyze(result, query, isNavMode);
    }
}